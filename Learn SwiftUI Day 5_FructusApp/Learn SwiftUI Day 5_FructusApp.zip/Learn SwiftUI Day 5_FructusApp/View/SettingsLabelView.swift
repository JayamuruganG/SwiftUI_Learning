//
//  SettingsLabelView.swift
//  Learn SwiftUI Day 4_FructusApp
//
//  Created by Jayamurugan on 17/03/24.
//

import SwiftUI

struct SettingsLabelView: View {
  //MARK: - Properties
  var labelText: String
  var labelImage: String
  //MARK: - Body
    var body: some View {
      HStack{
        Text(labelText.uppercased()).fontWeight(.bold)
        Spacer()
        Image(systemName: labelImage)
      }
    }
}

#Preview(traits: .sizeThatFitsLayout){
  SettingsLabelView(labelText: "Fructus", labelImage: "info.circle")
    .padding()
}
