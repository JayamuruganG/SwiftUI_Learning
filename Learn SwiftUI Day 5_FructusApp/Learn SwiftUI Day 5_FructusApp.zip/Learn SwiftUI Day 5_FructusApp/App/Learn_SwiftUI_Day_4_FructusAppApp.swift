//
//  Learn_SwiftUI_Day_4_FructusAppApp.swift
//  Learn SwiftUI Day 4_FructusApp
//
//  Created by Jayamurugan on 16/03/24.
//

import SwiftUI

@main
struct Learn_SwiftUI_Day_4_FructusAppApp: App {
  @AppStorage("isOboarding") var isOboarding: Bool = true
    var body: some Scene {
        WindowGroup {
          if isOboarding{
            OnboardingView()
          }else{
            ContentView()
          }
        }
    }
}
