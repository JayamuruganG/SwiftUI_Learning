//
//  StartButtonView.swift
//  Learn SwiftUI Day 4_FructusApp
//
//  Created by Jayamurugan on 16/03/24.
//

import SwiftUI

struct StartButtonView: View {
  //MARK: - Properties
  @AppStorage("isOboarding") var isOboarding: Bool?
  //MARK: - Body
    var body: some View {
      Button {
        isOboarding = false
      } label: {
        HStack(spacing: 8) {
          Text("Start")

          Image(systemName: "arrow.right.circle")
            .imageScale(.large)
        }//: HStack
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(
          Capsule().strokeBorder(Color.white, lineWidth: 1.25)
        )
      }//: Button
      .accentColor(.white)

    }
}

#Preview {
    StartButtonView()
    .previewLayout(.sizeThatFits)
}
