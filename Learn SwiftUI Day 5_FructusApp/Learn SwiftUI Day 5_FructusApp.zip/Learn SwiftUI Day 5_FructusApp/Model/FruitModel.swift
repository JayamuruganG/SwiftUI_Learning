//
//  FruitModel.swift
//  Learn SwiftUI Day 4_FructusApp
//
//  Created by Jayamurugan on 16/03/24.
//

import SwiftUI

//MARK: - Fruits data model
struct Fruit: Identifiable{
  var id = UUID()
  var title: String
  var headLine: String
  var image: String
  var gradientColors: [Color]
  var description: String
  var nutrition: [String]
}

