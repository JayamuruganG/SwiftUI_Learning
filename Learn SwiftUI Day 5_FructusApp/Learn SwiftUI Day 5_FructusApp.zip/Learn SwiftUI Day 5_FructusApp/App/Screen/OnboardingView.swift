//
//  OnboardingView.swift
//  Learn SwiftUI Day 4_FructusApp
//
//  Created by Jayamurugan on 16/03/24.
//

import SwiftUI

struct OnboardingView: View {
  //MARK: - Properties
  var fruits: [Fruit] = fruitsData
  //MARK: - Body
    var body: some View {
      TabView{
        ForEach(fruits[0...5]) { item in
          FruitCardView(fruit: item)
        }//: Loop
      }//: TAB
      .tabViewStyle(PageTabViewStyle())
      .padding(.vertical, 20)
    }
}

#Preview {
    OnboardingView(fruits: fruitsData)
    .previewDevice("iPhone 11 Pro")
}
