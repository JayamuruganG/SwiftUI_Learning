//
//  SourceLinkView.swift
//  Learn SwiftUI Day 4_FructusApp
//
//  Created by Jayamurugan on 17/03/24.
//

import SwiftUI

struct SourceLinkView: View {
    var body: some View {
      GroupBox(){
        HStack{
          Text("Content source")
          Spacer()
          Link("Wikipedia", destination: URL(string: "https://wikipedia.com")!)
          Image(systemName: "arrow.up.right.square")
        }//: HStack
        .font(.footnote)
      }//: GroupBox
    }
}

#Preview(traits: .sizeThatFitsLayout) {
    SourceLinkView()
    .padding()
}
